# model settings
norm_cfg = dict(type='SyncBN', requires_grad=True)
data_preprocessor = dict(
    type='DualInputSegDataPreProcessor',
    mean=[123.675, 116.28, 103.53] * 2,
    std=[58.395, 57.12, 57.375] * 2,
    bgr_to_rgb=True,
    size_divisor=32,
    pad_val=0,
    seg_pad_val=255,
    test_cfg=dict(size_divisor=32))

model = dict(
    type='DIEncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='VRWKVPidi6',
        img_size=256,
        patch_size=16,
        embed_dims=256,
        dnum_heads=6,
        depth=12,
        pretrained=None,
        init_values=1,
        with_cp=False,
        drop_path_rate=0.1,
        conv_inplane=60,
        n_points=4,
        deform_ratio=1.0,
        interaction_indexes=[[0, 2], [3, 5], [6, 8], [9, 11]],
        pretrained_edge=None),
    decode_head=dict(
        type='RSRNeck6', inplanes=256, num_classes=2,
        loss_decode=[
            dict(type='mmseg.CrossEntropyLoss', use_sigmoid=True, loss_name='loss_ce', loss_weight=1.0),
            dict(type='mmseg.DiceLoss', use_sigmoid=True, loss_name='loss_dice', loss_weight=1.0)]),
    # model training and testing settings
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

