from copy import deepcopy
import torch
import torch.nn as nn
import torch.nn.functional as F
from model.conbine.Decoder import FPNNeck
# from collections import OrderedDict
from model.conbine.vrwkv_edge import VRWKVPidi


class RSR(nn.Module):
    def __init__(self, img_size=256, inplanes=192, out_channels=2):
        super().__init__()
        self.img_size = img_size
        self.backbone = VRWKVPidi(img_size=256,
                                  patch_size=16,
                                  embed_dims=192,
                                  depth=12,
                                  pretrained=None,
                                  init_values=1,
                                  with_cp=False,
                                  drop_path_rate=0.1,
                                  conv_inplane=60,
                                  n_points=4,
                                  deform_num_heads=6,
                                  deform_ratio=1.0,
                                  interaction_indexes=[[0, 2], [3, 5], [6, 8], [9, 11]],
                                  pretrain_edge=True)
        self.dl = None
        self.auxiliary_head = False
        self.inplanes = inplanes
        self.neck = FPNNeck(self.inplanes, num_classes =out_channels, neck_name='fpn+fuse')

        # self._model_summary(self.img_size)

# 从backbone中提取四个尺度的特征，然后通过neck融合，最后通过head输出
    def forward(self, xa, xb):
        _, _, h_input, w_input = xa.shape
        assert xa.shape == xb.shape, "The two images are not the same size, please check it."

        fa1, fa2, fa3, fa4 = self.backbone(xa)  # feature_a_1: 输入图像a的最大输出特征图
        fb1, fb2, fb3, fb4 = self.backbone(xb)

        ms_feats = fa1, fa2, fa3, fa4, fb1, fb2, fb3, fb4   # 多尺度特征

        change = self.neck(ms_feats)

        # out = self.head_forward(ms_feats, change, out_size=(h_input, w_input))

        return change

    def head_forward(self, ms_feats, change, out_size):
        fa1, fa2, fa3, fa4, fb1, fb2, fb3, fb4 = ms_feats

        out1 = F.interpolate(self.head(change), size=out_size, mode='bilinear', align_corners=True)
        out2 = F.interpolate(self.head(change), size=out_size,
                             mode='bilinear', align_corners=True) if self.dl else None

        if self.training and self.auxiliary_head:
            aux_stage1_out1 = F.interpolate(self.aux_stage1_head(torch.cat([fa1, fb1], 1)),
                                            size=out_size, mode='bilinear', align_corners=True)
            aux_stage1_out2 = F.interpolate(self.aux_stage1_head(torch.cat([fa1, fb1], 1)),
                                            size=out_size, mode='bilinear', align_corners=True) if self.dl else None
            aux_stage2_out1 = F.interpolate(self.aux_stage2_head(torch.cat([fa2, fb2], 1)),
                                            size=out_size, mode='bilinear', align_corners=True)
            aux_stage2_out2 = F.interpolate(self.aux_stage2_head(torch.cat([fa2, fb2], 1)),
                                            size=out_size, mode='bilinear', align_corners=True) if self.dl else None
            aux_stage3_out1 = F.interpolate(self.aux_stage3_head(torch.cat([fa3, fb3], 1)),
                                            size=out_size, mode='bilinear', align_corners=True)
            aux_stage3_out2 = F.interpolate(self.aux_stage3_head(torch.cat([fa3, fb3], 1)),
                                            size=out_size, mode='bilinear', align_corners=True) if self.dl else None
            aux_stage4_out1 = F.interpolate(self.aux_stage4_head(torch.cat([fa4, fb4], 1)),
                                            size=out_size, mode='bilinear', align_corners=True)
            aux_stage4_out2 = F.interpolate(self.aux_stage4_head(torch.cat([fa4, fb4], 1)),
                                            size=out_size, mode='bilinear', align_corners=True) if self.dl else None
            return (out1, out2,
                    aux_stage1_out1, aux_stage1_out2, aux_stage2_out1, aux_stage2_out2,
                    aux_stage3_out1, aux_stage3_out2, aux_stage4_out1, aux_stage4_out2) \
                if self.dl else (out1, aux_stage1_out1, aux_stage2_out1, aux_stage3_out1, aux_stage4_out1)
        else:
            return (out1, out2) if self.dl else out1


    # def _model_summary(self, input_size):
    #     input_sample = torch.randn(1, 3, input_size, input_size)  # for encoder
    #     flops, params = profile(self, inputs=(input_sample, input_sample), verbose=False)
    #     flops, params = clever_format([flops, params], "%.3f")
    #     print("\n" + "-" * 30 + "Model Summary" + "-" * 30)
    #     print("Params: {}; When input shape is (3,{},{}), Flops: {} "
    #           .format(params, input_size, input_size, flops))


class ModelEMA:
    def __init__(self, model, decay=0.96):
        self.shadow1 = deepcopy(model.module if self.is_parallel(model) else model).eval()
        self.decay = decay
        for p in self.shadow1.parameters():
            p.requires_grad_(False)

        self.shadow2 = deepcopy(self.shadow1)
        self.shadow3 = deepcopy(self.shadow1)   # 第0代的权重设为0
        self.update_count = 0

    def update(self, model):
        with torch.no_grad():
            msd = model.module.state_dict() if self.is_parallel(model) else model.state_dict()
            for k, v in self.shadow1.state_dict().items():
                if v.dtype.is_floating_point:
                    v *= self.decay
                    v += (1. - self.decay) * msd[k].detach()   # += 是本地操作，其值原地修改
            for k, v in self.shadow2.state_dict().items():
                if v.dtype.is_floating_point:
                    v *= 0.95
                    v += (1. - 0.95) * msd[k].detach()   # += 是本地操作，其值原地修改
            for k, v in self.shadow3.state_dict().items():
                if v.dtype.is_floating_point:
                    v *= 0.94
                    v += (1. - 0.94) * msd[k].detach()   # += 是本地操作，其值原地修改
        self.update_count += 1

    @staticmethod
    def is_parallel(model):
        return type(model) in (nn.parallel.DataParallel, nn.parallel.DistributedDataParallel)


if __name__ == '__main__':
    # 设置随机种子以确保结果的可重复性
    torch.manual_seed(0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 创建 RSRWKV 实例
    model = RSR(img_size=256, inplanes=192, out_channels=2).to(device)

    # 创建 ModelEMA 实例
    model_ema = ModelEMA(model, decay=0.96)

    # 创建随机输入数据
    input_tensor_a = torch.randn(1, 3, 256, 256).to(device)
    input_tensor_b = torch.randn(1, 3, 256, 256).to(device)

    # 前向传播
    output = model(input_tensor_a, input_tensor_b)
    print("Output shape:", output.shape)






