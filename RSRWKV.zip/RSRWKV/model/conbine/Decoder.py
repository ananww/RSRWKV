import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import pywt
import pywt.data

from dropblock import LinearScheduler, DropBlock2D
from mmseg.models.decode_heads.decode_head import BaseDecodeHead

from functools import partial

from ..backbones.vrwkv6 import DecodeBlock6
from opencd.registry import MODELS


class Conv3Relu(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super(Conv3Relu, self).__init__()
        self.extract = nn.Sequential(nn.Conv2d(in_ch, out_ch, (3, 3), padding=(1, 1),
                                               stride=(stride, stride), bias=False),
                                     nn.BatchNorm2d(out_ch),
                                     nn.ReLU(inplace=True))

    def forward(self, x):
        x = self.extract(x)
        return x


class Conv1Relu(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(Conv1Relu, self).__init__()
        self.extract = nn.Sequential(nn.Conv2d(in_ch, out_ch // 2, (1, 1), bias=False),
                                     nn.BatchNorm2d(out_ch),
                                     nn.ReLU(inplace=True))

    def forward(self, x):
        x = self.extract(x)
        return x


class BasicBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(BasicBlock, self).__init__()

        self.relu = nn.ReLU(inplace=True)
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, (3, 3), (stride, stride), padding=(1, 1), bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, (3, 3), (1, 1), padding=(1, 1), bias=False),
            nn.BatchNorm2d(out_channels)
        )
        self.downsample = None
        if stride == 2:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, (3, 3), (stride, stride), padding=(1, 1), bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True)
            )

    def forward(self, x):
        if self.downsample is not None:
            residual = self.downsample(x)
        else:
            residual = x
        x = self.block(x) + residual
        x = self.relu(x)
        return x


class DropBlock(nn.Module):
    """
    [Ghiasi et al., 2018] DropBlock: A regularization method for convolutional networks
    """
    def __init__(self, rate=0.15, size=7, step=50):
        super().__init__()

        self.drop = LinearScheduler(
            DropBlock2D(block_size=size, drop_prob=0.),
            start_value=0,
            stop_value=rate,
            nr_steps=step
        )
        # print('-' * 100)
        # print('dropblock is initialized successfully!')
        # print('block_size={}, drop_prob={}, step={}'.format(size, rate, step))

    def forward(self, feats: list):
        if self.training:  # 只在训练的时候加上dropblock
            for i, feat in enumerate(feats):
                feat = self.drop(feat)
                feats[i] = feat
        return feats

    def step(self):
        self.drop.step()
        # print("drop_prob = {}".format(self.drop.dropblock.drop_prob))


def dropblock_step(model):
    """
    更新 dropblock的drop率
    """
    neck = model.module.neck if hasattr(model, "module") else model.neck
    if hasattr(neck, "drop"):
        neck.drop.step()


@MODELS.register_module()
class RSRNeck6(BaseDecodeHead):
    def __init__(self, inplanes, num_classes=2, **kwargs):
        super().__init__(in_channels=inplanes, channels=0, num_classes=num_classes, **kwargs)

        self.stage1_Conv1 = Conv3Relu(inplanes * 2, inplanes)  # channel: 2*inplanes ---> inplanes
        self.rwkv1 = DecodeBlock6(n_embd=inplanes, n_head=3, n_layer=2, shift_mode='q_shift_multihead', shift_pixel=1,
                                  drop_path=0., hidden_rate=4, init_mode='fancy', init_values=None, post_norm=False,
                                  key_norm=False, with_cls_token=False, with_cp=False)
        self.stage2_Conv1 = Conv3Relu(inplanes * 2, inplanes)  # channel: 4*inplanes ---> 2*inplanes
        self.rwkv2 = DecodeBlock6(n_embd=inplanes, n_head=3, n_layer=2, shift_mode='q_shift_multihead', shift_pixel=1,
                                  drop_path=0., hidden_rate=4, init_mode='fancy', init_values=None, post_norm=False,
                                  key_norm=False, with_cls_token=False, with_cp=False)
        self.stage3_Conv1 = Conv3Relu(inplanes * 2, inplanes)  # channel: 8*inplanes ---> 4*inplanes
        self.rwkv3 = DecodeBlock6(n_embd=inplanes, n_head=3, n_layer=2, shift_mode='q_shift_multihead', shift_pixel=1,
                                  drop_path=0., hidden_rate=4, init_mode='fancy', init_values=None, post_norm=False,
                                  key_norm=False, with_cls_token=False, with_cp=False)
        self.stage4_Conv1 = Conv3Relu(inplanes * 2, inplanes)  # channel: 16*inplanes ---> 8*inplanes
        self.rwkv4 = DecodeBlock6(n_embd=inplanes, n_head=3, n_layer=2, shift_mode='q_shift_multihead', shift_pixel=1,
                                  drop_path=0., hidden_rate=4, init_mode='fancy', init_values=None, post_norm=False,
                                  key_norm=False, with_cls_token=False, with_cp=False)

        self.stage1_Conv2 = Conv3Relu(inplanes * 2, inplanes)
        self.stage2_Conv2 = Conv3Relu(inplanes * 2, inplanes)
        self.stage3_Conv2 = Conv3Relu(inplanes * 2, inplanes)

        self.stage2_Conv3 = Conv3Relu(inplanes, inplanes)   # 降维
        self.stage3_Conv3 = Conv3Relu(inplanes, inplanes)
        self.stage4_Conv3 = Conv3Relu(inplanes, inplanes)

        self.final_Conv = Conv3Relu(inplanes * 4, inplanes)

        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        rate, size, step = (0.15, 7, 30)
        self.drop = DropBlock(rate=rate, size=size, step=step)

        inter_channels = inplanes // 4
        self.head = nn.Sequential(Conv3Relu(inplanes, inter_channels),
                                  nn.Dropout(0.2),  # 使用0.1的dropout
                                  nn.Conv2d(inter_channels, num_classes, (1, 1)))

    def _init_weights(self, m):
        if isinstance(m, nn.LayerNorm) or isinstance(m, nn.BatchNorm2d):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, ms_feats):
        fa1, fa2, fa3, fa4, fb1, fb2, fb3, fb4 = ms_feats
        change1_h, change1_w = fa1.size(2), fa1.size(3)

        [fa1, fa2, fa3, fa4, fb1, fb2, fb3, fb4] = self.drop([fa1, fa2, fa3, fa4, fb1, fb2, fb3, fb4])  # dropblock

        change1 = self.stage1_Conv1(torch.cat([fa1, fb1], 1))   # inplanes
        change1 = self.rwkv1(change1, patch_resolution=(change1_h, change1_w))
        change2 = self.stage2_Conv1(torch.cat([fa2, fb2], 1))   # inplanes * 2
        change2 = self.rwkv2(change2, patch_resolution=(change1_h // 2, change1_w // 2))
        change3 = self.stage3_Conv1(torch.cat([fa3, fb3], 1))  # inplanes * 4
        change3 = self.rwkv3(change3, patch_resolution=(change1_h // 4, change1_w // 4))
        change4 = self.stage4_Conv1(torch.cat([fa4, fb4], 1))  # inplanes * 8
        change4 = self.rwkv4(change4, patch_resolution=(change1_h // 8, change1_w // 8))

        change3_2 = self.up(change4)
        change3 = self.stage3_Conv2(torch.cat([change3, change3_2], 1))

        change2_2 = self.up(change3)
        change2 = self.stage2_Conv2(torch.cat([change2, change2_2], 1))

        change1_2 = self.up(change2)
        change1 = self.stage1_Conv2(torch.cat([change1, change1_2], 1))

        change4 = self.stage4_Conv3(F.interpolate(change4, size=(change1_h, change1_w),
                                                  mode='bilinear', align_corners=True))
        change3 = self.stage3_Conv3(F.interpolate(change3, size=(change1_h, change1_w),
                                                  mode='bilinear', align_corners=True))
        change2 = self.stage2_Conv3(F.interpolate(change2, size=(change1_h, change1_w),
                                                  mode='bilinear', align_corners=True))

        [change1, change2, change3, change4] = self.drop([change1, change2, change3, change4])  # dropblock

        change = self.final_Conv(torch.cat([change1, change2, change3, change4], 1))

        change = nn.functional.interpolate(change, size=(change.size(2) * 4, change .size(3) * 4), mode='bilinear', align_corners=True)
        change = self.head(change)

        return  change


