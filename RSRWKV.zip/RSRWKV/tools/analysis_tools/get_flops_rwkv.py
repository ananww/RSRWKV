# Copyright (c) Open-CD. All rights reserved.
import argparse
from pathlib import Path

import torch
from mmengine import Config, DictAction
from mmengine.logging import MMLogger
from mmengine.model import revert_sync_batchnorm
from mmengine.registry import init_default_scope
from mmseg.registry import MODELS
from ptflops import get_model_complexity_info

# --------------- VRWKV6计算函数 ---------------
TIME_MIX_EXTRA_DIM = 32
TIME_DECAY_EXTRA_DIM = 64


def vrwkv6_flops(n, dim, head_size):
    """精确的VRWKV6块FLOPs计算"""
    return n * (dim * (TIME_MIX_EXTRA_DIM * 10 + TIME_DECAY_EXTRA_DIM * 2 + 7 * head_size + 17) +
                (TIME_MIX_EXTRA_DIM * 5 + TIME_DECAY_EXTRA_DIM))


def get_vrwkv6_additional_flops(backbone, h, w):
    n_patches = h * w
    return len(backbone.layers) * vrwkv6_flops(
        n_patches,
        backbone.embed_dims,
        backbone.embed_dims // backbone.num_heads
    )


def parse_args():
    parser = argparse.ArgumentParser(description='Get model FLOPs and parameters')
    parser.add_argument('config', help='config file path')
    parser.add_argument('--shape', type=int, nargs='+', default=[256, 256], help='input image size')
    parser.add_argument('--cfg-options', nargs='+', action=DictAction, help='override config options')
    return parser.parse_args()


def inference(args: argparse.Namespace, logger: MMLogger) -> dict:
    try:
        # 初始化配置和模型
        cfg = Config.fromfile(args.config)
        if args.cfg_options:
            cfg.merge_from_dict(args.cfg_options)

        init_default_scope(cfg.get('scope', 'opencd'))
        model = MODELS.build(cfg.model)
        model = revert_sync_batchnorm(model).eval()

        if torch.cuda.is_available():
            model = model.cuda()

            # 正确准备输入数据（6通道张量）
            H, W = args.shape if len(args.shape) == 2 else (args.shape[0], args.shape[0])
            input_shape = (6, H, W)  # 双时相合并为6通道
            dummy_input = torch.randn(1, *input_shape)
            if torch.cuda.is_available():
                dummy_input = dummy_input.cuda()

            # 修改自定义算子前向传播
            from opencd.models.backbones.vrwkv6 import WKV_6
            original_forward = WKV_6.forward

            def patched_forward(ctx, B, T, C, H, r, k, v, w, u):
                if torch.jit.is_tracing() or torch._C._get_tracing_state():
                    return torch.zeros(B, T, C, device=r.device)
                return original_forward(ctx, B, T, C, H, r, k, v, w, u)

            WKV_6.forward = patched_forward

            # 使用ptflops计算
            with torch.jit.optimized_execution(False):
                macs, params = get_model_complexity_info(
                    model,
                    input_shape,
                    input_constructor=lambda _: {"inputs": dummy_input},  # 适配Open-CD数据格式
                    as_strings=False,
                    print_per_layer_stat=False,
                    verbose=False
                )

            # 计算VRWKV6额外FLOPs
            if hasattr(model, 'backbone') and 'VRWKV6' in str(type(model.backbone)):
                backbone = model.backbone
                patch_size = backbone.patch_embed.patch_size
                h = H // patch_size[0]
                w = W // patch_size[1]
                macs += get_vrwkv6_additional_flops(backbone, h, w)

            # 恢复原始前向传播
            WKV_6.forward = original_forward

            return {
                'flops': f"{macs / 1e9:.2f} G" if macs else "N/A",
                'params': f"{params / 1e6:.2f} M" if params else "N/A",
                'shape': (H, W)
            }

    except Exception as e:
        logger.error(f"Inference error: {str(e)}", exc_info=True)
        return {'flops': 'Error', 'params': 'Error', 'shape': args.shape}


def main():
    args = parse_args()
    logger = MMLogger.get_current_instance()
    try:
        result = inference(args, logger)
        print(
            f"\n{'=' * 30}\nInput Shape: {result['shape']}\nFLOPs: {result['flops']}\nParams: {result['params']}\n{'=' * 30}")
    except Exception as e:
        logger.error(f"Final error: {str(e)}")


if __name__ == '__main__':
    main()